# HRC L2 Humanoid Leg — Design Archive 1

- **Year:** 2025
- **Context:** HRC · L2 Team

## Summary

Contributed structural design work for a humanoid leg as part of the HRC L2 team. The team produced a complete, functional 3D-printed leg; it was not stress-tested or integrated into a larger assembly.

These files belong to one L2 project. The historical “phase” folder names identify the supplied file groups, not distinct project milestones. See the [combined project summary](../../README.md).

## Objective

Create a stiff, adaptable shin structure with clearance for ankle and knee components.

## Design Constraints

- Resist forward/backward bending and axial compression.
- Limit stress concentrations.
- Allow clearance for neighboring joints and future revisions.
- Plan CNC machining for the final design or sheet-metal forming for a test prototype.

## Engineering Work

Designed the shin core and nonstructural slide-in platforms, with two Unitree motors intended to drive ankle linkages. Supporting files include beam-bending documentation, analysis figures, and a MATLAB optimization script.

## Outcome and Evidence

The HRC L2 team produced a complete, functional 3D-printed leg. It was never stress-tested or integrated into a larger assembly. The metal I-beam concepts and simulations in the design files are design studies, not evidence of load validation of the printed leg.

## Media

| Asset | Format |
| --- | --- |
| [notes figs / i beam](../../media/archive-1--notes-figs--i-beam.jpg) | JPG |
| [notes figs / shin core deformation fs8](../../media/archive-1--notes-figs--shin-core-deformation-fs8.png) | PNG |
| [notes figs / shin core vmstress](../../media/archive-1--notes-figs--shin-core-vmstress.png) | PNG |
| [notes figs / shin core](../../media/archive-1--notes-figs--shin-core.png) | PNG |
| [notes figs / shin foot](../../media/archive-1--notes-figs--shin-foot.png) | PNG |
| [phase 1 / linkage sysytems / digit](../../media/archive-1--phase-1--linkage-sysytems--digit.png) | PNG |
| [phase 1 / linkage sysytems / g1 i think](../../media/archive-1--phase-1--linkage-sysytems--g1-i-think.png) | PNG |
| [phase 1 / linkage sysytems / gr 1](../../media/archive-1--phase-1--linkage-sysytems--gr-1.png) | PNG |
| [phase 1 / linkage sysytems / gr 2](../../media/archive-1--phase-1--linkage-sysytems--gr-2.png) | PNG |

## Source Files

- [beamBendingDocumention.docx](beamBendingDocumention.docx)
- [beamBendingDocumention.pdf](beamBendingDocumention.pdf)
- [Notes & Figs](Notes%20%26%20Figs/)
- [Phase 1](Phase%201/)
- [samoi_maximization.m](samoi_maximization.m)
- [Summary - ShinQuad.txt](Summary%20-%20ShinQuad.txt)

Original notes, native CAD filenames, and source subdirectories are preserved as supplied. Summary statements use the supplied project notes and existing portfolio; design intentions are distinguished from documented results.
