# HRC L2 Humanoid Leg — Design Archive 2

- **Year:** 2025
- **Context:** HRC · L2 Team

## Summary

Contributed structural design work for a humanoid leg as part of the HRC L2 team. The team produced a complete, functional 3D-printed leg; it was not stress-tested or integrated into a larger assembly.

These files belong to one L2 project. The historical “phase” folder names identify the supplied file groups, not distinct project milestones. See the [combined project summary](../../README.md).

## Objective

Develop a manufacturable leg structure that carries axial and shear loads while resisting forward/backward bending.

## Design Constraints

- Use purchased I-beams with minimal modification.
- Reserve CNC machining or prototype sheet-metal forming for parts that require it.
- Maintain axial strength and bending stiffness.
- Limit stress concentrations.

## Engineering Work

Specified stock I-beams (McMaster-Carr 8003K208), shin and thigh connectors, and a knee-bearing clamp. The assembly incorporates three Unitree motors for the ankle linkages and knee; the bearing arrangement supports the knee against unwanted roll.

## Outcome and Evidence

The HRC L2 team produced a complete, functional 3D-printed leg. It was never stress-tested or integrated into a larger assembly. The metal I-beam concepts and simulations in the design files are design studies, not evidence of load validation of the printed leg.

## Media

| Asset | Format |
| --- | --- |
| [leg 3 30 2025 2](../../media/archive-2--leg-3-30-2025-2.png) | PNG |
| [notes figs / i beam](../../media/archive-2--notes-figs--i-beam.jpg) | JPG |
| [notes figs / shin core deformation fs8](../../media/archive-2--notes-figs--shin-core-deformation-fs8.png) | PNG |
| [notes figs / shin core vmstress](../../media/archive-2--notes-figs--shin-core-vmstress.png) | PNG |
| [notes figs / shin core](../../media/archive-2--notes-figs--shin-core.png) | PNG |
| [notes figs / shin foot](../../media/archive-2--notes-figs--shin-foot.png) | PNG |
| [phase 2 / knee / knee 3 30 2025](../../media/archive-2--phase-2--knee--knee-3-30-2025.png) | PNG |
| [phase 2 / shin calf / notes figs / i beam](../../media/archive-2--phase-2--shin-calf--notes-figs--i-beam.jpg) | JPG |
| [phase 2 / shin calf / notes figs / shin core deformation fs8](../../media/archive-2--phase-2--shin-calf--notes-figs--shin-core-deformation-fs8.png) | PNG |
| [phase 2 / shin calf / notes figs / shin core vmstress](../../media/archive-2--phase-2--shin-calf--notes-figs--shin-core-vmstress.png) | PNG |
| [phase 2 / shin calf / notes figs / shin core](../../media/archive-2--phase-2--shin-calf--notes-figs--shin-core.png) | PNG |
| [phase 2 / shin calf / notes figs / shin foot quad](../../media/archive-2--phase-2--shin-calf--notes-figs--shin-foot-quad.png) | PNG |
| [phase 2 / shin calf / notes figs / shin foot](../../media/archive-2--phase-2--shin-calf--notes-figs--shin-foot.png) | PNG |

## Source Files

- [beamBendingDocumention.docx](beamBendingDocumention.docx)
- [beamBendingDocumention.pdf](beamBendingDocumention.pdf)
- [Notes & Figs](Notes%20%26%20Figs/)
- [Phase 2](Phase%202/)
- [samoi_maximization.m](samoi_maximization.m)
- [Summary - ShinQuadKnee.txt](Summary%20-%20ShinQuadKnee.txt)

Original notes, native CAD filenames, and source subdirectories are preserved as supplied. Summary statements use the supplied project notes and existing portfolio; design intentions are distinguished from documented results.
