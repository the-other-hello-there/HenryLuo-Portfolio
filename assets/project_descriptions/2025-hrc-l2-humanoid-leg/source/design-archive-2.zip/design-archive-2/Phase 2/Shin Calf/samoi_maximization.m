function [] = samoi_maximization()
% Refer to beambending.docx; all units in mm
    % Assuming h=b=10mm
    % I_xx = 20/3*(R*cos(t)-10)^3+1000/3*R*sin(t)+10*R*sin(t)*(2*R*cos(t)-10)^2
    % I_yy = 500*(R*cos(t)-10)/3+40*R^3*(sin(t))^3/3

    % Assuming h=b=3mm
    % I_xx = 2*(R*cos(t)-3)^3+9*R*sin(t)+3*R*sin(t)*(2*R*cos(t)-3)^2
    % I_yy = 9*(R*cos(t)-3)/2+4*R^3*(sin(t))^3

    R = 42.0;
    t = 0;
    I_xx = 0;
    I_yy = 0;
    I_xx_max = 0;
    t_xx_max = 0;
    I_yy_max = 0;
    t_yy_max = 0;
    for(t = 0:360)
        I_xx = 2*(R*cosd(t/4.0)-3)^3+9*R*sind(t/4.0)+3*R*sind(t/4.0)*(2*R*cosd(t/4.0)-3)^2;
        I_yy = 9*(R*cosd(t/4.0)-3)/2+4*R^3*(sind(t/4.0))^3;
        if(I_xx > I_xx_max)
            I_xx_max = I_xx;
            t_xx_max = t/4.0;
        end
        if(I_yy > I_yy_max)
            I_yy_max = I_yy;
            t_yy_max = t/4.0;
        end
    end
    H_xx = 2*(R*cosd(t_xx_max) - 10);
    B_xx = 2*R*sind(t_xx_max);
    H_yy = 2*(R*cosd(t_yy_max) - 10);
    B_yy = 2*R*sind(t_yy_max);
    fprintf("Max I_xx: %.4f mm^4\nAngle: %.2f deg\nH: %.4f mm\nB: %.4f mm\n\n", I_xx_max, t_xx_max, H_xx, B_xx);
    fprintf("Max I_yy: %.4f mm^4\nAngle: %.2f deg\nH: %.4f mm\nB: %.4f mm\n", I_yy_max, t_yy_max, H_yy, B_yy);
end